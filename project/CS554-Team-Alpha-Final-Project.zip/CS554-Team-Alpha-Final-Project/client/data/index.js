const profile = require("./profile")
module.exports = {
    profile:profile
}