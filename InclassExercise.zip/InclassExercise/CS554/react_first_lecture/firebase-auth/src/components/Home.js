import React from "react";

const Home = () => (
  <div>
    <h1>Hello, this is the Homepage</h1>
  </div>
);

export default Home;
