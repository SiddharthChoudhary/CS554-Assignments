import React from "react";

const SignIn = () => (
  <div>
    <h1>Hello, this is the Sign-In page</h1>
  </div>
);

export default SignIn;
