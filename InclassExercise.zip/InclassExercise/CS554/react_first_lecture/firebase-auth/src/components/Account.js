import React from "react";

const Account = () => (
  <div>
    <h1>Hello, this is the account page</h1>
  </div>
);

export default Account;
