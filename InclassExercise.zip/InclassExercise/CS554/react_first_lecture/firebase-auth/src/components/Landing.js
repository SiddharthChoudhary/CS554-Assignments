import React from "react";

const Landing = () => (
  <div>
    <h1>Hello, this is the Landing page</h1>
  </div>
);

export default Landing;
