import React from "react";

const ChangePassword = () => (
  <div>
    <h1>Hello, this is the Forgotten password page</h1>
  </div>
);

export default ChangePassword;
