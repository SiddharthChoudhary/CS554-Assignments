import React from "react";

const SignUp = () => (
  <div>
    <h1>Hello, this is the SignUp page</h1>
  </div>
);

export default SignUp;
