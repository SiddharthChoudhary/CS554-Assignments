import React from "react";

const ForgotPassword = () => (
  <div>
    <h1>Hello, this is the Forgotten password page</h1>
  </div>
);

export default ForgotPassword;
