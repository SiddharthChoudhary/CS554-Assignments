# Firebase Auth #

This is the code for the React/Firebase Auth project we are doing in class.