<template>
  <div id="app">
    <Skills />
  </div>
</template>

<script>
import Skills from './components/Skills.vue'

export default {
  name: 'app',
  components: {
    Skills
  }
}
</script>

<style>
body{
  background-color: #eeeeee;
}
</style>
