
## GraphQL Using Apollo Server, Apollo Client and React

This is just a simple example of using GraphQL with Apollo server and a client done with Apollo Client and React


## To Run this
`npm install` on the root dir for the server
`npm start` to start the server
`cd client`
`npm install` to install the client
`npm start` to start the client

