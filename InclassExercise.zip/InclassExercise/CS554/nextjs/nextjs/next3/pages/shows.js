import Header from "../components/Header";
const Shows = () => (
  <div>
    <Header />
    <h1>Shows List Page</h1>
  </div>
);

export default Shows;
