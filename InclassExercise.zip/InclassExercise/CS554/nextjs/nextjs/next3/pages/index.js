import Header from "../components/Header";
const Index = () => (
  <div>
    <Header />
    <h1>Hello Next.js</h1>
  </div>
);

export default Index;
