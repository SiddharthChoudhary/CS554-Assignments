import Header from "../components/Header";
const Show = () => (
  <div>
    <Header />
    <h1>Show details</h1>
  </div>
);

export default Show;
