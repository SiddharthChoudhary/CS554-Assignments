const Shows = () => (
  <div>
    <h1>Shows List Page</h1>
  </div>
);

export default Shows;
