const Index = () => (
  <div>
    <h1>Hello Next.js</h1>
  </div>
);

export default Index;
