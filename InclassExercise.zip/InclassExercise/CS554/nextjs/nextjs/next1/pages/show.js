const Show = () => (
  <div>
    <h1>Show details</h1>
  </div>
);

export default Show;
