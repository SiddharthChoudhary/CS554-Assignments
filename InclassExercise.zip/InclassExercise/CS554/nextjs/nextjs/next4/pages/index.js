import Layout from "../components/MyLayout";
const Index = () => (
  <Layout>
    <h1>Hello Next.js</h1>
  </Layout>
);

export default Index;
