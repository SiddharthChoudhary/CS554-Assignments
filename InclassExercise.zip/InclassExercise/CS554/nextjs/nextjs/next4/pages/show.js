import Layout from "../components/MyLayout";
const Show = () => (
  <Layout>
    <h1>Show details</h1>
  </Layout>
);

export default Show;
