import Layout from "../components/MyLayout";
const Shows = () => (
  <Layout>
    <h1>Shows List Page</h1>
  </Layout>
);

export default Shows;
